import _libpyenc
